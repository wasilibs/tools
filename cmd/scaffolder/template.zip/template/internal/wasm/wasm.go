package wasm

import _ "embed"
